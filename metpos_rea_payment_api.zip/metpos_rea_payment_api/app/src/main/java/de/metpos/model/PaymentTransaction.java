package de.metpos.model;

public class PaymentTransaction {
    private String transactionType;

    private String tenderType;
    private String amount;
    private String tipAmount;
    private String taxAmount;
    private String transactionId;
    private String transactionData;
    private String recieptPrinterColumns;

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getTenderType() {
        return tenderType;
    }

    public void setTenderType(String tenderType) {
        this.tenderType = tenderType;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getTipAmount() {
        return tipAmount;
    }

    public void setTipAmount(String tipAmount) {
        this.tipAmount = tipAmount;
    }

    public String getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(String taxAmount) {
        this.taxAmount = taxAmount;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getTransactionData() {
        return transactionData;
    }

    public void setTransactionData(String transactionData) {
        this.transactionData = transactionData;
    }

    public String getRecieptPrinterColumns() {
        return recieptPrinterColumns;
    }

    public void setRecieptPrinterColumns(String recieptPrinterColumns) {
        this.recieptPrinterColumns = recieptPrinterColumns;
    }


}
