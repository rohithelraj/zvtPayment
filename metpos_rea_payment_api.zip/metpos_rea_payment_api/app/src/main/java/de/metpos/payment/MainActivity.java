package de.metpos.payment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    public static  String cloudParam1 = null;
    public static  String cloudParam2 = null;
    public static Socket socket = null;
    public static void initializeCommunication(){
        try {
            socket = new Socket("172.30.78.21", 22000);
            DataInputStream dIn = new DataInputStream(socket.getInputStream());
            DataOutputStream dOut = new DataOutputStream(socket.getOutputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        String action = getIntent().getAction() == null? "" : getIntent().getAction();
        if(action.equals("icg.actions.electronicpayment.metpos_rea_payment_api.INITIALIZE")){
            initialize();
        }
        else if(action.equals("icg.actions.electronicpayment.metpos_rea_payment_api.SHOW_SETUP_SCREEN")){
            showSetupScreen();

        }
        else if(action.equals("icg.actions.electronicpayment.metpos_rea_payment_api.FINALIZE")){
            confirmConnectionsClosed();
        }
        else if (action.equals("icg.actions.electronicpayment.metpos_rea_payment_api.GET_BEHAVIOR"))
        {
            doGetBehavior();
        }
        else if (action.equals("icg.actions.electronicpayment.metpos_rea_payment_api.GET_VERSION"))
        {
            doGetVersion();
        }
        else if (action.equals("icg.actions.electronicpayment.metpos_rea_payment_api.TRANSACTION"))
        {
            doPerformTransaction();
        }
        else
        {
            setResult(RESULT_CANCELED);
            finish();
        }
    }

    private void initialize() {
        Intent result = new Intent("icg.actions.electronicpayment.metpos_rea_payment_api.INITIALIZE");
        cloudParam1 = result.getStringExtra("CLOUD_ID1");
        cloudParam2 = result.getStringExtra("CLOUD_ID2");
        if(!cloudParam1.equals(null) && !cloudParam2.equals(null)){
            setResult(RESULT_OK);
        }
        else{
            result.putExtra("ErrorMessage", "Failed to initialize with cloud parameters!");
            setResult(RESULT_CANCELED,result);
        }

    }
    private void showSetupScreen(){
        Intent result = new Intent("icg.actions.electronicpayment.metpos_rea_payment_api.SHOW_SETUP_SCREEN");

    }
    private void confirmConnectionsClosed(){
        Intent result = new Intent("icg.actions.electronicpayment.metpos_rea_payment_api.FINALIZE");
        try {
            finalize();
            setResult(RESULT_OK);
        } catch (Throwable throwable) {
            result.putExtra("ErrorMessage", "Failed to finalize!");
            setResult(RESULT_CANCELED,result);
        }

    }
    private void doGetBehavior()
    {
        Intent result = new Intent("icg.actions.electronicpayment.metpos_rea_payment_api.GET_BEHAVIOR");

        result.putExtra("SupportsTransactionVoid", false);
        result.putExtra("SupportsTransactionQuery", false);
        result.putExtra("SupportsNegativeSales", false);
        result.putExtra("SupportsPartialRefund", false);
        result.putExtra("SupportsBatchClose", false);
        result.putExtra("SupportsTipAdjustment", false);
        result.putExtra("OnlyCreditForTipAdjustment", false);
        result.putExtra("SupportsCredit", true);
        result.putExtra("SupportsDebit", true);
        result.putExtra("SupportsEBTFoodstamp", false);

        setResult(RESULT_OK, result);
        finish();
    }

    private void doGetVersion()
    {
        Intent result = new Intent("icg.actions.electronicpayment.metpos_rea_payment_api.GET_VERSION");
        result.putExtra("Version", 1003);
        setResult(RESULT_OK, result);
        finish();
    }

    private void doPerformTransaction() {
        Intent result = new Intent("icg.actions.electronicpayment.metpos_rea_payment_api.TRANSACTION");
        String transaction_name = result.getStringExtra("TransactionType");
        String tender_type = result.getStringExtra("TenderType");
        String currency_iso = result.getStringExtra("Currency ISO");
        String amount = result.getStringExtra("Amount");
        String tipAmount = result.getStringExtra("TipAmount");
        String taxAmount = result.getStringExtra("TaxAmount");
        String transactionId = result.getStringExtra("TransactionId");
        String transactionData = result.getStringExtra("TransactionData");
        String receiptPrinterColumns = result.getStringExtra("ReceiptPrinterColumns");
        initializeCommunication();
        switch(transaction_name){
            case "SALE":
                try {
                    payment(amount);
                } catch (IOException e) {
                    System.out.println("Socket connection with EC Card device failed!");
                }

            case "NEGATIVE_SALE":

            case "REFUND":

            case "ADJUST_TIPS":

            case "VOID_TRANSACTION":

            case "QUERY_TRANSACTION":

            default:
        }

        switch(tender_type){
            case "CREDIT":

            case "DEBIT":

            case "EBT_FOODSTAMP":

            default:
        }


        result.putExtra("ErrorMessage", "Not implemented yet");
        setResult(RESULT_CANCELED, result);
        finish();
    }

    public static void payment(String amount) throws IOException {
        //payment
        DataOutputStream dOut = new DataOutputStream(socket.getOutputStream());
        DataInputStream dIn = new DataInputStream(socket.getInputStream());
        String money[] = amount.split(",");
        String euro = money[0];
        String cent = money[1];
        byte eurobyte = Byte.parseByte(euro,16);
        byte centbyte = Byte.parseByte(cent,16);
        try {
            TimeUnit.SECONDS.sleep(5);
        }catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        //byte[] commandLeft = {(byte)0x06, (byte)0x01, (byte)0x09, (byte)0x04, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)eurobyte, (byte)centbyte, (byte)0x19, (byte)0x01, (byte)0x00, (byte)0x40};
        byte[] commandLeft = {(byte)0x06, (byte)0x01, (byte)0x09, (byte)0x04, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)eurobyte, (byte)centbyte, (byte)0x19, (byte)0x00};
        byte[] commandSuccess = {(byte)0x80, (byte)0x00, (byte)0x00};
        dOut.write(commandLeft);
        try {
            TimeUnit.SECONDS.sleep(5);
        }catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        String dataString = "";
        while (true) {
            dataString += dIn.read();
            if (dataString.contains("12800")) {
                try {
                    TimeUnit.SECONDS.sleep(1);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                System.out.println("Betrag empfangen, f�hre Zahlung aus!");
                break;

            }
        }

        while (true) {
            dataString += (char)dIn.read();
            if (dataString.contains("Bitte Karte\neinstecken")) {
                try {
                    TimeUnit.SECONDS.sleep(1);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                dOut.write(commandSuccess);
                System.out.println("Bitte Karte einstecken!");
                break;
            }
        }

        while (true) {
            dataString += (char)dIn.read();
            if (dataString.contains("Karte entnehmen")) {
                try {
                    TimeUnit.SECONDS.sleep(1);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                dOut.write(commandSuccess);
                System.out.println("Bitte Karte entnehmen!");
                break;
            }
        }

        while (true) {
            dataString += (char)dIn.read();
            if (dataString.contains("ec")) {
                try {
                    TimeUnit.SECONDS.sleep(1);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                dOut.write(commandSuccess);
                System.out.println("Zahlungsart: EFT offline\nDie Zahlung wurde erfolgreich durchgef�hrt.");
                System.out.println();
                System.out.println("Erm�chtigung zum Lastschrifteinzug\n\nIch erm�chtige oben genanntes Unternehmen, den heute f�lligen, o.g. Betrag unter o.g. Mandats-Referenz (M-ID) einmalig von meinem durch die verwendete Karte identifizierten Konto per Lastschrifteinzugs einzuziehen. Die Frist zur Ank�ndigung des Lastschrifteinzuges wird auf einen Tag verk�rzt. Die Belastung meines Kontos erfolgt an dem Gesch�ftstag, der dieser Zahlung folgt. Hinweis: Ich kann innerhalb von 8 Wochen, beginnend mit dem Belastungsdatum, die Erstattung des belasteten Betrages verlangen. Es gelten dabei die mit meinem Kreditinstitut vereinbarten Bedingungen.\n\nIch weise mein Kreditinstitut unwiderruflich an,\n\ndie Lastschrift einzul�sen und im Falle der Nichteinl�sung der Lastschrift dem o. g. Unternehmen, oder, bei Forderungsabtretung, dem jeweiligen Gl�ubiger oder deren Beauftragten auf Anforderung meinen Namen und meinen Anschrift zur Geltendmachung oder Forderung mitzuteilen.\n\n\n\n________________________________\nUnterschrift des Karteninhabers\n\n\nDatenschutzrechtliche Informationen\n\nWir erfassen Ihre Zahlungsinformationen (Kontonummer, Bankleitzahl, Kartenverfalldatum, und-folgenummer, Datum, Uhrzeit, Betrag, Terminalkennung, Standort des Terminals) zum Zweck der Zahlungsabwicklung, zur Kartenpr�fung und Verhinderung von Kartenmissbrauch.\nWird bei einer Zahlung im Elektronischen Lastschriftverfahren (d. h. mit Girocard und Unterschrift) eine Lastschrift von Ihrer Bank nicht eingel�st oder von Ihnen widerrufen (R�cklastschrift), wird dies in eine Sperrdatei eingetragen, die bei oben genannter Firma gef�hrt wird. Solange ein Sperreintrag besteht, ist eine Zahlung mit Girocard und Unterschrift nicht m�glich. Der Eintrag in der Sperrdatei wird gel�scht, sobald die Forderung vollst�ndig beglichen wurde oder wenn Sie Rechte aus dem get�tigten Kauf geltend machen (z.B. bei Sachmangel oder R�ckgabe der Ware");
                break;

            }
        }
        socket.close();

    }
}
