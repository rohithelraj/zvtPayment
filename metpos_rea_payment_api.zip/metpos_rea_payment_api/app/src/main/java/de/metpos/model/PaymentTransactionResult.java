package de.metpos.model;

public class PaymentTransactionResult {

    private String transactionType;
    private String amount;
    private String tipAmount;
    private String taxAmount;
    private String transactionData;
    private String merchantReciept;
    private String customerReciept;
    private String errorMessage;
    private String transactionResult;

    public String getTransactionResult() {
        return transactionResult;
    }

    public void setTransactionResult(String transactionResult) {
        this.transactionResult = transactionResult;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getTipAmount() {
        return tipAmount;
    }

    public void setTipAmount(String tipAmount) {
        this.tipAmount = tipAmount;
    }

    public String getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(String taxAmount) {
        this.taxAmount = taxAmount;
    }

    public String getTransactionData() {
        return transactionData;
    }

    public void setTransactionData(String transactionData) {
        this.transactionData = transactionData;
    }

    public String getMerchantReciept() {
        return merchantReciept;
    }

    public void setMerchantReciept(String merchantReciept) {
        this.merchantReciept = merchantReciept;
    }

    public String getCustomerReciept() {
        return customerReciept;
    }

    public void setCustomerReciept(String customerReciept) {
        this.customerReciept = customerReciept;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

}
